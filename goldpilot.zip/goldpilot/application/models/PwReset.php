<?php

class PwReset extends ActiveRecord\Model
{
    public static $table_name = 'pw_reset';
}
